module.exports = {
    HOST: "localhost",
    USER: "postgres",
    PASSWORD: "1234",
    DB: "universitiesDB",
    dialect: "postgres",
    port: 5432
};